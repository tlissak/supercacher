<?php
include('init.class.php') ;
$gui = new GUI() ;

?>